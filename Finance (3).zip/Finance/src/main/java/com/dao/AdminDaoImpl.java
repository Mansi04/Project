package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.Admin;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDaoIntf {

	public boolean validateAdmin(Admin admin) {
		boolean flag=false;
		
		Admin f =null;
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			f=(Admin)em.createQuery("SELECT f FROM Admin f WHERE f.username=:username and f.password=:password")
		         .setParameter("username", admin.getUsername())
		         .setParameter("password", admin.getPassword())
		         .getSingleResult();
			System.out.println(f);
			
			if(f!=null){
			//	if(f.getAdpass().equals(admin.getPassword())
					flag=true;
			}
			em.close();
		}
		catch(Exception e) {System.out.println(e); }
		
		System.out.println(f);
		return flag;
		}
	
	public boolean changepasswrd(String username, String opwd, String npwd) {
		 boolean flag=false;
		  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	 
		  em.getTransaction().begin();
		  Query query = em.createQuery("update Admin u set u.password=:npwd where u.username=:username and u.password=:opwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("opwd", opwd);
		  query.setParameter("username", username);
		   int r = query.executeUpdate();
		  em.getTransaction().commit();
		  System.out.println("working");
		  em.close();
		  if(r>0)
			  flag=true;
		  return flag;
	  }
		
	}


