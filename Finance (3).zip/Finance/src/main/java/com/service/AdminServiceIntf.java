package com.service;

import com.model.Admin;

public interface AdminServiceIntf {
	public boolean validateAdmin(Admin admin);
	public boolean changepasswrd(String adname,String opwd, String npwd);
}
