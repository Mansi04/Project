package com.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Users;
import com.service.UserServiceImpl;

@Controller
public class UserController {

	@Autowired
	UserServiceImpl userservice;

	@RequestMapping(value="/register" ,method=RequestMethod.POST )
	public ModelAndView registerUser(HttpServletRequest request,HttpServletResponse response){
		
		String app_id= "A"+ new Date().getTime();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String contact_no=request.getParameter("contact");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String card_type=request.getParameter("card_type");
		String bank=request.getParameter("bank");
		String account_no=request.getParameter("account_no");
		String ifsc=request.getParameter("ifsc");
		String status="pending";
		
		
		Users users =null;
		users = new Users(app_id,fname, lname, contact_no, email, username, password, address, card_type, bank, account_no, ifsc, status);
		
		boolean flag= userservice.registerUser(users);
		
		if(flag){
			     ModelAndView mav = new ModelAndView("home");
			     mav.addObject("username", username);
				mav.addObject("status", "You have successfully registered. Please visit our nearest branch for further verification");
				mav.addObject("users",users);
				return mav;
		}
		else
		{
			ModelAndView mav = new ModelAndView("home1");
			mav.addObject("status", "Not Registered");
			return mav;
		}

		
	}
	
}
