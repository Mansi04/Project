package com.dao;

import com.model.Users;

public interface UserDao {

	public boolean registerUser(Users users); 
}
