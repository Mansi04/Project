package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.model.Users;

@Repository("userDao")
public class UserDaoImpl implements UserDao{

	
	public boolean registerUser(Users users) {
		boolean result= false;
		try {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(users);
			System.out.println("in persist");
			em.getTransaction().commit();
			System.out.println("in commit");
			
			result=true;
			
			
		} catch (Exception e) {
			
			System.out.println(e);
			System.out.println("User already registered");
		}
			
		return result;
		
	}
	
	//view all products
	/*public List<Products> getAllMembers(){
		People p = null;
		List<People> mlist =new ArrayList<People>();
		try{
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			Query q = em.createQuery("from People");
			mlist = q.getResultList();
			em.close();
			
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return mlist;
	}*/

}
