package com.service;

import com.model.Users;

public interface UserService {

	public boolean registerUser(Users users);
}
