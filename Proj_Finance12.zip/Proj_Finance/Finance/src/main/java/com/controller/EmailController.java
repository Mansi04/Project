/*package com.controller;
@Controller
public class EmailController {

	
	
		@Autowired
		private MailService mailService; 
		@RequestMapping(value="/")
		public String homePage()
		{
			return "index"; 
		}
		
		@RequestMapping(value="/forgotPassword")
		public String forgotPassword()
		{
			return "forgotPassword"; 
		}
		
		@RequestMapping(value="/resetPassword" , method=RequestMethod.POST)
		public String resetRequest(@RequestParam(value="email") String email)
		{
			//check if the email id is valid and registered with us.
			mailService.sendMail(email);
			return "checkMail";
		}
		
		@RequestMapping(value="/newPassword/{email}" )
		public String resetPassword(@PathVariable String email,Map<String,String> model)
		{
			//check if the email id is valid and registered with us.
			model.put("emailid", email);
			return "newPassword";
		}

	}

}
*/