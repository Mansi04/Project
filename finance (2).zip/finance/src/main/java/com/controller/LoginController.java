package com.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.model.CreditCard;
import com.model.User;

import com.service.UserServiceIntf;

@Controller("mycontroller")
public class LoginController 
{
	@Autowired
	UserServiceIntf userService;
	
	 @RequestMapping(value = "/register", method = RequestMethod.GET)
	  public ModelAndView showRegister2(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("register");
	    mav.addObject("user", new User());
	    return mav;
	  }
	 
	  @RequestMapping(value = "/registerProcess2", method = RequestMethod.POST)
	  public ModelAndView addUser2(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("user") User user, @RequestParam("file") MultipartFile files[]) {
		  String username = user.getUsername();
			for (int i = 0; i < files.length; i++) {
				//upload
				String filename="";
				if(i==0)
					filename=(username+i)+".pdf";
					else if(i==1)
						filename=(username+i)+".pdf";
					
				MultipartFile file = files[i];
				try {
					byte[] bytes = file.getBytes();

					// Creating the directory to store file
					String rootPath = System.getProperty("catalina.home");
					File dir = new File(rootPath + File.separator + "tmpFiles");
					if (!dir.exists())
						dir.mkdirs();

					// Create the file on server
					File serverFile = new File(dir.getAbsolutePath()+ File.separator + filename);
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();
					
					if(i==0)
                   user.setAddress_fname(filename);
					else if(i==1)
						user.setAccount_no_fname(filename);
					
					user.setStatus("N");
					
					System.out.println("Server File Location="+ serverFile.getAbsolutePath());
					} catch (Exception e) {
					System.out.println( "You failed to upload " + (username+i) + " => " + e.getMessage());
				}
			}  
		  
		boolean flag=userService.register(user);
	    if(flag) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("login", new User());
	    return mav;
	    }
	    else {
	    	ModelAndView mav = new ModelAndView("register");
	        mav.addObject("user", new User());
	        mav.addObject("status","Sorry! Registration in incomplete");
	        return mav;	
	    }
	  }
	  
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("loginuser");
	    mav.addObject("user", new User());
	    return mav;
	     }

	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response, @ModelAttribute User iuser) {
	    String username=request.getParameter("username");
	    String password=request.getParameter("password");
	    System.out.println(username+"\n"+password);
	    User user=new User();
	    user.setUsername(username);
	    user.setPassword(password);
	          
	     
	    
	     boolean flag = userService.validateUser(user);
	     
	       if(flag) {
	    	   ModelAndView mav = new ModelAndView();
     	 mav.addObject("status","Login Success");
     	 //session manage
	      HttpSession session= request.getSession();
          session.setAttribute("username", username);
          mav.setViewName("Welcome");
          return mav;
      }
      else {
    	  ModelAndView mav = new ModelAndView();
     	 mav.addObject("status","Login Failed");
     	mav.setViewName("loginuser");
     	return mav;
      }
            
       
	  }
	  
	  @RequestMapping(value = "/changepasswrd", method = RequestMethod.GET)
	  public ModelAndView changepwd1(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("changepasswrd");
	    return mav;
	  }
	@RequestMapping(value = "/changepasswrd", method = RequestMethod.POST)
	  public ModelAndView changepwd2(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String username=(String)session.getAttribute("username");
        String opwd= request.getParameter("opassword");
        String npwd= request.getParameter("npassword");
        System.out.println(username+"  "+opwd+"  "+npwd);
        boolean flag = userService.changepasswrd(username,opwd,npwd);
        if(flag) {
	       ModelAndView mav = new ModelAndView("changepasswrd");
	       mav.addObject("message", "Password is successfully updated");
	       return mav;
	  }
        else {
        	ModelAndView mav = new ModelAndView("changepasswrd");
		       mav.addObject("message", "Password is not updated");
		       return mav;
        }
	}
	@RequestMapping(value = "/creditcard", method = RequestMethod.GET)
	public ModelAndView getCards() {
		List<CreditCard>  cardlist = userService.getCards();
		 System.out.println(cardlist);
		 ModelAndView mav = new ModelAndView("creditcard");
		
		 mav.addObject("cardlist", cardlist);
		// HttpSession session =request.getSession(false);
		 //session.setAttribute("clist", cardlist);
		 return mav;
	 }
}
	  




