package com.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.CreditCard;
import com.model.User;


import oracle.jdbc.util.Login;
@Repository("userDao")
public class UserDaoImp implements UserDaoIntf {
	
	public boolean register(User user) {
		boolean flag=false;
	    try {
	    EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin( ); 
		em.persist(user);
		em.getTransaction().commit();
		em.close();
		System.out.println("end");
		flag=true;
	    }
	    catch(Exception e) { System.out.println("Error:"+e);  }
	    return flag;
	  }

	public boolean validateUser(User user){ 
		boolean flag=false;
	
	User f =null;
	try{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		f=(User)em.createQuery("SELECT f FROM User f WHERE f.username=:uname and f.password=:pwd")
	         .setParameter("uname", user.getUsername())
	         .setParameter("pwd",user.getPassword())
	         .getSingleResult();
		System.out.println(f);
		f=em.find(User.class, user.getUsername());
		if(f!=null){
			if(f.getPassword().equals(user.getPassword()))
				flag=true;
		}
		em.close();
	}
	catch(Exception e) {System.out.println(e); }
	
	System.out.println(f);
	return flag;
	}
	
	
	/*public List<User> getUsers() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  @SuppressWarnings("unchecked")
			List<User> users = em.createQuery("SELECT u FROM  User u").getResultList();
		  em.close();
		  return  users;
		  }*/

	public boolean changepasswrd(String username, String opwd, String npwd) {
		 boolean flag=false;
		  EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	 
		  em.getTransaction().begin();
		  Query query = em.createQuery("update User u set u.password=:npwd where u.username=:username and u.password=:opwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("opwd", opwd);
		  query.setParameter("username", username);
		   int r = query.executeUpdate();
		  em.getTransaction().commit();
		  System.out.println("working");
		  em.close();
		  if(r>0)
			  flag=true;
		  return flag;
	  }

	public List<CreditCard> getCards() {
		System.out.println("Dao Called");
		CreditCard c =null;
		List<CreditCard> clist = new ArrayList<CreditCard>();
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();	
			@SuppressWarnings("unchecked")
			List<CreditCard> cards = em.createQuery("SELECT c FROM CreditCard c").getResultList();
		 
			return  cards;
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return clist;
	}

	public List<User> getUsers() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		  EntityManager em = emf.createEntityManager();	  
		  @SuppressWarnings("unchecked")
			List<User> user = em.createQuery("SELECT u FROM  User u").getResultList();
		  em.close();
		  return  user;
	}
	}
	

	

