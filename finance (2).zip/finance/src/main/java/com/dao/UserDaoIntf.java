package com.dao;

import java.util.List;

import com.model.CreditCard;
import com.model.User;
import oracle.jdbc.util.Login;

public interface UserDaoIntf {
	boolean register(User user);
	/*User validateUser(User user);*/
	boolean validateUser(User user);
	public List<User> getUsers();
	 boolean changepasswrd(String username,String opwd, String npwd);
	List<CreditCard> getCards();

}
