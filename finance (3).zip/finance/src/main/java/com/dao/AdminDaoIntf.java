package com.dao;

import com.model.Admin;

public interface AdminDaoIntf {
	boolean validateAdmin(Admin admin);
	 boolean adchngepass(String adname,String opwd, String npwd);
}
