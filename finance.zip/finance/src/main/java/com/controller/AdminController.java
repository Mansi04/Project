package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Admin;

import com.service.AdminServiceIntf;

@Controller("mycontroller1")
public class AdminController {

	@Autowired
	AdminServiceIntf adminService;
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("loginadmin");
	    mav.addObject("admin", new Admin());
	    return mav;
	     }
	 @RequestMapping(value = "/adminProcess", method = RequestMethod.POST)
	  public ModelAndView adminProcess(HttpServletRequest request, HttpServletResponse response, @ModelAttribute Admin iadmin) {
	    String adname=request.getParameter("adname");
	    String adpass=request.getParameter("adpass");
	    Admin admin=new Admin();
	   admin.setAdname(adname);
	   admin.setAdpass(adpass);
	   ModelAndView mav = new ModelAndView();
	    
	     boolean flag = adminService.validateAdmin(admin);
	     mav.addObject("adname",adname);
	     mav.addObject("adpass", adpass);
	     if(flag) {
	     	 mav.addObject("status","Login Success");
	     	 HttpSession session= request.getSession();
	          session.setAttribute("adname", adname);
	          mav.setViewName("Welcome");
	          return mav;
	      }
	      else {
	     	 mav.addObject("status","Login Failed");
	     	mav.setViewName("loginadmin");
	     	return mav;
	      }
	   
	 }
	 
	 @RequestMapping(value = "/adchngepass", method = RequestMethod.GET)
	  public ModelAndView changepwd1(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("adchngepass");
	    return mav;
	  }
	@RequestMapping(value = "/adchngepass", method = RequestMethod.POST)
	  public ModelAndView changepwd2(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
       String adname=(String)session.getAttribute("adname");
       String opwd= request.getParameter("opassword");
       String npwd= request.getParameter("npassword");
       System.out.println(adname+"  "+opwd+"  "+npwd);
       boolean flag = adminService.adchngepass(adname,opwd,npwd);
       if(flag) {
	       ModelAndView mav = new ModelAndView("adchngepass");
	       mav.addObject("message", "Password is successfully updated");
	       return mav;
	  }
       else {
       	ModelAndView mav = new ModelAndView("adchngepass");
		       mav.addObject("message", "Password is not updated");
		       return mav;
       }
	}         
	}
