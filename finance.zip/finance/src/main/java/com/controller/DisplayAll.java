package com.controller;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class DisplayAll {

	public static void main(String[] args) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			
			
			Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			Statement smt = (Statement) cn.createStatement();
			
			
			String q="Select * from CardDetails";
			
			
			ResultSet rs=((java.sql.Statement) smt).executeQuery(q);
			
			
			if(rs.next()){ 
				do{
				System.out.println(rs.getString(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getString(4)+","+rs.getString(5));
				}while(rs.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
			cn.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
	


