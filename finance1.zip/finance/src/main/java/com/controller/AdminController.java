package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Admin;

import com.service.AdminServiceIntf;

@Controller("mycontroller1")
public class AdminController {

	@Autowired
	AdminServiceIntf adminService;
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("loginadmin");
	    mav.addObject("admin", new Admin());
	    return mav;
	     }
	 @RequestMapping(value = "/adminProcess", method = RequestMethod.POST)
	  public ModelAndView adminProcess(HttpServletRequest request, HttpServletResponse response, @ModelAttribute Admin iadmin) {
	    String adname=request.getParameter("adname");
	    String adpass=request.getParameter("adpass");
	    Admin admin=new Admin();
	   admin.setAdname(adname);
	   admin.setAdpass(adpass);
	   ModelAndView mav = new ModelAndView();
	    
	     boolean flag = adminService.validateAdmin(admin);
	     mav.addObject("adname",adname);
	     mav.addObject("adpass", adpass);
	     if(flag) {
	     	 mav.addObject("status","Login Success");
	      }
	      else {
	     	 mav.addObject("status","Login Failed");
	      }
	      mav.setViewName("Welcome");
	      return mav;
	 }
	          
}
