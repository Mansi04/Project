package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.model.Admin;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDaoIntf {

	public boolean validateAdmin(Admin admin) {
		boolean flag=false;
		
		Admin f =null;
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			f=(Admin)em.createQuery("SELECT f FROM Admin f WHERE f.adname=:adname and f.adpass=:adpass")
		         .setParameter("adname", admin.getAdname())
		         .setParameter("adpass", admin.getAdpass())
		         .getSingleResult();
			System.out.println(f);
			f=em.find(Admin.class,admin.getAdname());
			if(f!=null){
				if(f.getAdpass().equals(admin.getAdpass()))
					flag=true;
			}
			em.close();
		}
		catch(Exception e) {System.out.println(e); }
		
		System.out.println(f);
		return flag;
		}
		
	}


