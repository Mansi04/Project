package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	private String adname;
	private String adpass;
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getAdpass() {
		return adpass;
	}
	public void setAdpass(String adpass) {
		this.adpass = adpass;
	}
	public Admin() {
		super();
	}
	@Override
	public String toString() {
		return "Admin [adname=" + adname + ", adpass=" + adpass + "]";
	}
	

}
