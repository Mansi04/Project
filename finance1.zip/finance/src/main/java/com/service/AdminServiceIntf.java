package com.service;

import com.model.Admin;

public interface AdminServiceIntf {
	public boolean validateAdmin(Admin admin);

}
