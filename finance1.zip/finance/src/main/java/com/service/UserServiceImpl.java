package com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.UserDaoIntf;
import com.model.User;

import oracle.jdbc.util.Login;
@Service("userService")
public class UserServiceImpl implements UserServiceIntf {
	@Autowired
	  public UserDaoIntf userDao;

	public boolean register(User user) {
		return userDao.register(user);
		
	}
	public boolean validateUser(User user) {
		System.out.println("service called");
		boolean flag=userDao.validateUser(user);
		System.out.println(flag);
		return flag;
		/*return userDao.validateUser(user);*/
	}
	
	
	 public List<User> getUsers(){
		  List<User>  list = userDao.getUsers();
		  return list;
	  }
	
	public boolean changepasswrd(String username, String opwd, String npwd) {
		System.out.println("service called");
		boolean flag=userDao.changepasswrd(username, opwd, npwd);
		System.out.println(flag);
		 return flag;
	}
 
	 
	  
	}


